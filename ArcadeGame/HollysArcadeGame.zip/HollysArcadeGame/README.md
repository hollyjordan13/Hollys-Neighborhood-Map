frontend-nanodegree-arcade-game
===============================

# Holly's Arcade Game Project

Udacity Front-End Web Developer Nanodegree Part 3 Project: Classic Arcade Game.

## Table of Contents

* Project Overview
* Game Instructions
* Build Considerations
* Specifications
* Acknowledgements
* [Contributing](#contributing)

## Project Overview

This is a web browser version of the classic arcade game, Frogger. This project aims to demonstrate the skills I have learned so far in HTML, CSS and JavaScript. 

The project is available on GitHub, titled [Hollys-Arcade-Game](https://github.com/hollyjordan13/Hollys-Arcade-Game.git).

## Game Instructions

In this game you have a Player and Enemies (bugs). The goal of the player is to reach the water, without colliding into any one of the enemies.

The player can move left, right, up and down
The enemies move at varying speeds on the paved block portion of the game board
Once a the player collides with an enemy, the game is reset and the player moves back to the starting square
Once the player reaches the water (i.e., the top of the game board), the game is won


## Build Considerations

Based on the classic arcade game, 'Frogger', a player must hop through traffic and avoid being hit by cars in order to reach safety. The goal is to recreate this effect in this project. There are a couple of interactions that need to be considered:

- How the player will move across the board
- Constricting the player and enemies so that they cannot move beyond the boundaries of the board
- What happens when player collides with enemy
- When the win condtion is met
- Resetting the game

## Specifications

### Game Behavior

**Game Logic**

The player uses the arrow keys to move the "hero" across the tiles to reach safety on the other side. Player must avoid colliding with "enemies" or game will reset and player will return to the "start" position.

**Congratulations Alert**

When a user wins the game, an alert appears to congratulate the player.


### Interface Design

**Styling**

Application uses CSS to style components for the game.

**Usability**

All application components are usable across modern desktop, tablet, and phone browsers.

### Documentation

**README**

A README file is included detailing the game and all dependencies.

**Comments**

Comments are present and effectively explain longer code procedure when necessary.

**Code Quality**

Code is formatted with consistent, logical, and easy-to-read formatting as described in the Udacity JavaScript Style Guide.

For specific, detailed instructions, look at the project instructions in the [Udacity Classroom](https://classroom.udacity.com/me).

## Acknowledgements

* [Udacity](https://www.udacity.com/), for creating this degree program, and providing me with education and endless support
* [stackoverflow](https://stackoverflow.com/), for the collaborative forums and discussions which helped answer many of my questions
* [Mozilla Developer Network](https://developer.mozilla.org/en-US/), for so many resources and instructions

## Contributing

This repository is a project for the Udacity Front-End Web Developer Nanodegree. Therefore, we most likely will not accept pull requests.

For details, check out [CONTRIBUTING.md](CONTRIBUTING.md).



Students should use this [rubric](https://review.udacity.com/#!/projects/2696458597/rubric) for self-checking their submission. Make sure the functions you write are **object-oriented** - either class functions (like Player and Enemy) or class prototype functions such as Enemy.prototype.checkCollisions, and that the keyword 'this' is used appropriately within your class and class prototype functions to refer to the object the function is called upon. Also be sure that the **readme.md** file is updated with your instructions on both how to 1. Run and 2. Play your arcade game.

For detailed instructions on how to get started, check out this [guide](https://docs.google.com/document/d/1v01aScPjSWCCWQLIpFqvg3-vXLH2e8_SZQKC8jNO0Dc/pub?embedded=true).
